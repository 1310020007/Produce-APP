define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	require("$UI/system/lib/cordova/cordova");
	require("cordova!org.apache.cordova.device");
	require("cordova!org.apache.cordova.geolocation");
	require("cordova!com.justep.cordova.plugin.alipay");
	require("cordova!com.justep.cordova.plugin.baidulocation");
	require("cordova!com.justep.cordova.plugin.weixin.v3");
	require("$UI/Produce/appVersionChecker")
	var Model = function(){
		this.callParent();
		this.load = true ;
		this.loadOrder = true;
	};

	//增加过滤条件
	Model.prototype.modelLoad = function(event){
		//this.loginBtnClick(event);
	};
	
	//得到图片路径，将相对路径转换为绝对路径
	Model.prototype.getImgUrl = function(imgUrl){
		return require.toUrl("./img/"+imgUrl);
	};
	
	//主页的"来一份"按钮的点击事件
	Model.prototype.addCartBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		var rows = this.comp("cartData").find(["pID"], [row.getID()]);
		if(rows.length == 0){
			this.comp("cartData").newData({
				defaultValues:[{
					//为其购物车中的变量赋值，产品名，产品数量，产品单价
					"pID": row.getID(),
					"pName": row.val("pName"),
					"pPrice": row.val("pPrice"),
					"pCount": 1
				}]
			});
		}else{
			rows[0].val("pCount",rows[0].val("pCount")+1); 
		}
	};

	//购物车页的“+”按钮的点击操作事件
	Model.prototype.addBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		row.val("pCount",row.val("pCount") + 1);  //val();此方法是给一个参数是取值，给两个参数是赋值
	};
	//购物车页的“+”按钮的点击操作事件
	Model.prototype.subBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		if(row.val("pCount") > 0){
			row.val("pCount",row.val("pCount") - 1);  //val();此方法是给一个参数是取值，给两个参数是赋值
		}

	};

	//进行刷新页面
	Model.prototype.loadUserData = function(event){
		if(this.load){
			this.comp("input4").set({"readonly":false});
			this.comp("password1").set({"readonly":false});
			this.comp("input1").set({"readonly":true});
			this.comp("input2").set({"readonly":true});
			this.comp("input3").set({"readonly":true});
		}else{
			this.comp("input1").set({"readonly":false});
			this.comp("input2").set({"readonly":false});
			this.comp("input3").set({"readonly":false});
		}
	};
	
	//登录按钮的点击事件
	Model.prototype.loginBtnClick = function(event){
		var userID = this.comp("input4").val();
		var userPass = this.comp("password1").val();
		var rows = this.comp('userData').find(['userID','userPassword'],[userID,userPass]);
		if(rows.length == 0) {
			alert('没有符合条件数据');
			this.comp("password1").clear();
			this.comp("button3").set({"disabled":true});
			this.comp("button2").set({"disabled":true});
			this.comp("orderBtn").set({"disabled":true});
			this.comp("saveUserBtn").set({"disabled":true});
			this.comp("button1").set({"disabled":true});
			this.load = true;
			
		}else{
			alert('登录成功');
			this.comp("saveUserBtn").set({"disabled":false});
			this.comp("button1").set({"disabled":false});
			this.load = false;
			this.comp("password1").clear();
			this.comp("button3").set({"disabled":false});
			this.comp("button2").set({"disabled":false});
			this.comp("orderBtn").set({"disabled":false});
//			this.comp("input1").set({"readonly":false});
//			this.comp("input2").set({"readonly":false});
//			this.comp("input3").set({"readonly":false});
//			this.comp("input1").val(this.comp("userData").val("userName"));
//			this.comp("input2").val(this.comp("userData").val("userTel"));
//			this.comp("input3").val(this.comp("userData").val("userAddress"));
//			this.comp("userData").setFilter("filter1", "userID = '"+this.userID+"'");//过滤条件
//			this.comp("orderData").setFilter("filter2", "orderUserID = '"+this.userID+"'");
			
		}
	};

	Model.prototype.personContentActive = function(event){
		if(this.load){
			this.comp("button1").set({"disabled":true});
			this.comp("saveUserBtn").set({"disabled":true});
		}else{
			this.comp("button1").set({"disabled":false});
			this.comp("saveUserBtn").set({"disabled":false});
		}   
		this.loadUserData(event);
	};

	Model.prototype.cartContentActive = function(event){
		if(this.load){
			this.comp("orderBtn").set({"disabled":true});
		}else{
			this.comp("orderBtn").set({"disabled":false});
		}
		this.loadUserData(event);
	};
	
	//清空按钮的点击事件	
	Model.prototype.button4Click = function(event){
		this.comp("input4").set({"readonly":false});
		this.comp("input1").set({"readonly":false});
		this.comp("input2").set({"readonly":false});
		this.comp("input3").set({"readonly":false});
		this.comp("input4").clear();
		this.comp("input1").clear();
		this.comp("input2").clear();
		this.comp("input3").clear();
	};
	
	
	//注册按钮点击事件
	Model.prototype.btnClearInputClick = function(event){
		var id = this.comp("input4").val();
		var name = this.comp("input1").val();
		var password =this.comp("password1").val();
		var tel = this.comp("input2").val();
		var address = this.comp("input3").val();
		//alert(id);
		this.comp("userData").newData({
			index : 0,
			defaultValues : [ {
				"userID" : id,
				"userName" : name,
				"userPassword" : password,
				"userTel" : tel,
				"userAddress" : address
			} ]
		});
		this.comp("userData").saveData({
			"onSuccess" : function(){
				alert("注册成功");
			}
		});
		this.comp("input4").set({"readonly":false});
		this.comp("password1").set({"readonly":false});
		this.comp("input1").set({"readonly":true});
		this.comp("input2").set({"readonly":true});
		this.comp("input3").set({"readonly":true});
		this.comp("password1").clear();
		
	};

	//更新按钮的点击事件
	Model.prototype.button1Click = function(event){
		this.comp("input4").set({"readonly":true});
		this.comp("input1").set({"readonly":false});
		this.comp("input2").set({"readonly":false});
		this.comp("input3").set({"readonly":false});
	};

	//保存用户信息按钮的点击事件
	Model.prototype.saveUserBtnClick = function(event){
		var userData = this.comp("userData");
		this.comp("input4").val2ref();
		this.comp("input1").val2ref();
		this.comp("password1").val2ref();
		this.comp("input2").val2ref();
		this.comp("input3").val2ref();
	
		userData.saveData({
			"onSuccess" : function(){
				alert("用户信息保存成功");
			}
		});
	};

	Model.prototype.orderContentActive = function(event){
		if(this.loadOrder){   //判断是否需要加载
			this.comp("orderData").clear();  //清空订单页
			this.comp("orderlist").refresh(true);   //刷新
			this.loadOrder = false;
		}
	};
	
	//下单按钮的点击事件，用于把购物车中的订单提交到订单页面，并且跳转到订单页面
	//保存订单信息和用户信息 清空购物车  切换到订单页
	Model.prototype.orderBtnClick = function(event){
		var orderData = this.comp("orderData");
		var userData = this.comp("userData");
		var cartData = this.comp("cartData");
		var me = this;
		//var orderID = 100000 ;
		var orderID = justep.UUID.createUUID();
		var content = "";
		cartData.each(function(options) {
			content = content + options.row.val("pName") + "(" + options.row.val("pCount") + ")";
		});
		orderData.newData({
			index : 0,
			defaultValues:[{
				"orderID" : orderID,
				"orderCreateTime" : justep.Date.toString(new Date(), justep.Date.STANDART_FORMAT),//日期时间转换成字符串
				"orderContent" : content,
				"orderUserID" : userData.val("userID"),
				"orderUserName" : userData.val("userName"),
				"orderUserTel" : userData.val("userTel"),
				"orderAddress" : userData.val("userAddress"),
				"orderSum" : this.comp("calcData").val("pSumMoney")
			}]
		});
		//orderID++;
		orderData.saveData({
			"onSuccess" : function(){
				justep.Util.hint("下单成功");
				cartData.clear();  //清空购物车页
				me.comp("contents").to("orderContent");  //跳转至订单页
			},
			"error" : function(){
				justep.Util.hint("下单失败");
			}
		});
	};

	Model.prototype.orderDataSaveCreateParam = function(event){
		event.param.tables.push(this.comp("userData").toJson(true));  //同时保存用户信息
	};

	Model.prototype.orderDataSaveCommit = function(event){
		this.comp("userData").applyUpdates();
	};

	//定位按钮的点击事件
	Model.prototype.positioningBtnClick = function(event){
		var me = this;
		function successCallback(position) {
			alert("地址  " + position.address);
			//alert("坐标系  " + position.coorType);
			//alert("纬度  " + position.coords.latitude);
			//alert("经度  " + position.coords.longitude);
		}
		function errorCallback(error) {
			alert("失败！！");
		}
		navigator.geolocation.getCurrentPosition(successCallback,errorCallback);
	};
	
	
	//支付宝按钮的点击事件
	Model.prototype.button2Click = function(event){
		if (!navigator.alipay) {
			return;
		}
		var notifyUrl = location.origin;
		var tradeNo = justep.UUID.createUUID();
		var alipay = navigator.alipay;
		var money = this.comp("cartData").val("pMoney");
		alipay.pay({
		//由于支付宝商户申请不成功，只能使用X5的支付宝
			"seller" : "huangyx@justep.com", // 卖家支付宝账号或对应的支付宝唯一用户号
			"subject" : "农产品应用测试", // 商品名称
			"body" : "农产品应用测试", // 商品详情
			//"price" : "0.01", // 金额，单位为RMB
			"price" : money,
			"tradeNo" : tradeNo, // 唯一订单号
			"timeout" : "30m", // 超时设置
			"notifyUrl" : notifyUrl
		}, // 服务器通知路径
		function(message) {
			var responseCode = parseInt(message);
			alert("成功");
		}, function(msg) {
			alert("失败");
		});
	};

	//微信支付
	Model.prototype.button3Click = function(event){
		if (!navigator.weixin) {
			return;
		}
		var notifyUrl = location.origin;
		var traceID = justep.UUID.createUUID();
		var traceNo = justep.UUID.createUUID();
		//var money = (this.comp("cartData").val("pMoney")) * 100.00;
		var weixin = navigator.weixin;
		weixin.generatePrepayId({
			"body" : "x5外卖",
			"feeType" : "1",
			"notifyUrl" : notifyUrl,
			"totalFee" : "1",
			//"totalFee" : money,
			"traceId" : traceID,
			"tradeNo" : traceNo
		}, function(prepayId) {
			weixin.sendPayReq(prepayId, function(message) {
				var responseCode = parseInt(message);
				alert("成功");
			}, function(message) {
				justep.Util.hint("微信支付失败！");
			});
		}, function(prepayId) {
			justep.Util.hint("微信支付失败！");
		});
	};
	
	
	
	Model.prototype.searchKeyDataCustomRefresh = function(event){
		/*
		1、加载数据
		2、从localStorage缓存中加载数据
		*/
		var searchKeyData=event.source;
		try{
		   var data =  JSON.parse(localStorage.getItem("search_input_keys"));
		   searchKeyData.loadData(data);
		  }catch(e){
		   localStorage.removeItem("search_input_keys");
		}		
	};
	
	//搜索框	
	Model.prototype.keyInputFocus = function(event){
		/*
		1、搜索框获取焦点事件
		2、显示词库列表
		*/
		this.comp("keyInput").val("");
	};
	
	//搜索页搜索按钮点击事件
	Model.prototype.searchBtnTwoClick = function(event){
		/*
		1、获取搜索框值
		2、存入data和缓存
		3、打开 页面并传参
		*/

		var searchKeyData = this.comp("searchKeyData");
		var text=this.comp("keyInput").val();
		if(text.length>0 && searchKeyData.find(["key"],[text]).length==0){		
			var options = {
					defaultValues : [ {
						key : this.comp("keyInput").val()
					} ]
			};
			searchKeyData.newData(options);
			localStorage.setItem("search_input_keys",JSON.stringify(searchKeyData.toJson(true)));
		}
		//如何将搜索框输入的内容传入到主页中去
		//  暂缺
//		justep.Shell.showPage("list1",{
//			keyValue : this.comp("keyInput").val()
//		});
		alert("搜索暂缺");
		var searchKeyData=this.comp("searchKeyData");
		this.comp("contents").to("menuContent");  //跳转至主页
	};
	
	//清空搜索按钮的点击事件
	Model.prototype.clearBtnClick = function(event){
		localStorage.clear();
		this.comp("searchKeyData").clear();
	};
	
	//列表的点击事件
	Model.prototype.liClick = function(event){
		var searchKeyData=this.comp("searchKeyData");
		this.comp("contents").to("menuContent");  //跳转至主页
		this.comp("proData").setFilter("filter1", "pName like '%"+searchKeyData+"%'");//过滤条件
	};	
		
	
		
	return Model;
});