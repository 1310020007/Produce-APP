window.__justep.__ResourceEngine.loadCss([{url: '/v_e14bf280cf5144f89f8e77f3f2dcfe4el_zh_CNs_d_m/system/components/comp.min.css', include: '$model/system/components/justep/row/css/row,$model/system/components/justep/attachment/css/attachment,$model/system/components/justep/barcode/css/barcodeImage,$model/system/components/justep/panel/css/panel,$model/system/components/justep/common/css/scrollable,$model/system/components/justep/scrollView/css/scrollView,$model/system/components/justep/input/css/datePickerPC,$model/system/components/justep/contents/css/contents,$model/system/components/justep/popMenu/css/popMenu,$model/system/components/justep/lib/css/icons,$model/system/components/justep/titleBar/css/titleBar,$model/system/components/justep/dataTables/css/dataTables,$model/system/components/justep/dialog/css/dialog,$model/system/components/justep/messageDialog/css/messageDialog,$model/system/components/justep/toolBar/css/toolBar,$model/system/components/justep/popOver/css/popOver,$model/system/components/justep/loadingBar/loadingBar,$model/system/components/justep/input/css/datePicker,$model/system/components/justep/dataTables/css/dataTables,$model/system/components/justep/wing/css/wing,$model/system/components/bootstrap/scrollSpy/css/scrollSpy,$model/system/components/justep/menu/css/menu,$model/system/components/justep/numberSelect/css/numberList,$model/system/components/justep/list/css/list,$model/system/components/bootstrap/carousel/css/carousel,$model/system/components/bootstrap/dropdown/css/dropdown,$model/system/components/justep/common/css/forms,$model/system/components/justep/bar/css/bar'},{url: '/v_4140c339aa5947629cc5c7846eaa2bccl_zh_CNs_d_m/system/components/bootstrap.min.css', include: '$model/system/components/bootstrap/lib/css/bootstrap,$model/system/components/bootstrap/lib/css/bootstrap-theme'}]);window.__justep.__ResourceEngine.loadJs(['/v_fb3204705f4b453894aaaa026ac0a1adl_zh_CNs_d_m/system/components/comp2.min.js','/v_58b2d7f1de6a4dce98832984dadd9d33l_zh_CNs_d_m/system/components/comp.min.js','/v_4fa6905d4c404669b7a5cd97d4f824c2l_zh_CNs_d_m/system/common.min.js','/v_46ab3a431f524b488b8f2cc9500fb21al_zh_CNs_d_m/system/core.min.js']);define(function(require){
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/panel/panel');
require('$model/UI2/system/components/justep/button/buttonGroup');
require('$model/UI2/system/components/justep/list/list');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/bootstrap/panel/panel');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/contents/contents');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/scrollView/scrollView');
require('$model/UI2/system/components/justep/contents/content');
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/data/baasData');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/output/output');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Produce/index'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='crUBrA3';
	this._flag_='a109ad09b5b6f9ccabcbf736e3ba8be3';
	this.callParent(contextUrl);
 var __BaasData__ = require("$UI/system/components/justep/data/baasData");new __BaasData__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pDescript":{"define":"pDescript","label":"pDescript","name":"pDescript","relation":"pDescript","type":"String"},"pID":{"define":"pID","label":"pID","name":"pID","relation":"pID","type":"String"},"pImage":{"define":"pImage","label":"pImage","name":"pImage","relation":"pImage","type":"String"},"pName":{"define":"pName","label":"pName","name":"pName","relation":"pName","type":"String"},"pPrice":{"define":"pPrice","label":"pPrice","name":"pPrice","relation":"pPrice","rules":{"number":true},"type":"Decimal"}},"directDelete":false,"events":{},"idColumn":"pID","limit":20,"queryAction":"queryProt","tableName":"prot","url":"/Produce/Produce","xid":"proData"});
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":false,"autoNew":false,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pCount":{"define":"pCount","label":"数量","name":"pCount","relation":"pCount","rules":{"integer":true},"type":"Integer"},"pID":{"define":"pID","label":"产品id","name":"pID","relation":"pID","type":"String"},"pMoney":{"define":"pMoney","label":"金额","name":"pMoney","relation":"pMoney","rules":{"calculate":"$row.val(\"pPrice\") * $row.val(\"pCount\")","number":true},"type":"Float"},"pName":{"define":"pName","label":"名称","name":"pName","relation":"pName","type":"String"},"pPrice":{"define":"pPrice","label":"单价","name":"pPrice","relation":"pPrice","rules":{"number":true},"type":"Float"}},"directDelete":false,"events":{},"idColumn":"pID","limit":20,"xid":"cartData"});
 new __Data__(this,{"autoLoad":false,"autoNew":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pSumMoney":{"define":"pSumMoney","label":"合计金额","name":"pSumMoney","relation":"pSumMoney","rules":{"calculate":"$model.cartData.sum(\"pMoney\")","number":true},"type":"Float"}},"directDelete":false,"events":{},"idColumn":"pSumMoney","limit":20,"xid":"calcData"});
}}); 
return __result;});
