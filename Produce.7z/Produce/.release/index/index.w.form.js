define(function(require){
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/panel/panel');
require('$model/UI2/system/components/justep/button/buttonGroup');
require('$model/UI2/system/components/justep/list/list');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/bootstrap/panel/panel');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/contents/contents');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/scrollView/scrollView');
require('$model/UI2/system/components/justep/contents/content');
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/data/baasData');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/output/output');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Produce/index'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='crUBrA3';
	this._flag_='a109ad09b5b6f9ccabcbf736e3ba8be3';
	this.callParent(contextUrl);
 var __BaasData__ = require("$UI/system/components/justep/data/baasData");new __BaasData__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pDescript":{"define":"pDescript","label":"pDescript","name":"pDescript","relation":"pDescript","type":"String"},"pID":{"define":"pID","label":"pID","name":"pID","relation":"pID","type":"String"},"pImage":{"define":"pImage","label":"pImage","name":"pImage","relation":"pImage","type":"String"},"pName":{"define":"pName","label":"pName","name":"pName","relation":"pName","type":"String"},"pPrice":{"define":"pPrice","label":"pPrice","name":"pPrice","relation":"pPrice","rules":{"number":true},"type":"Decimal"}},"directDelete":false,"events":{},"idColumn":"pID","limit":20,"queryAction":"queryProt","tableName":"prot","url":"/Produce/Produce","xid":"proData"});
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":false,"autoNew":false,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pCount":{"define":"pCount","label":"数量","name":"pCount","relation":"pCount","rules":{"integer":true},"type":"Integer"},"pID":{"define":"pID","label":"产品id","name":"pID","relation":"pID","type":"String"},"pMoney":{"define":"pMoney","label":"金额","name":"pMoney","relation":"pMoney","rules":{"calculate":"$row.val(\"pPrice\") * $row.val(\"pCount\")","number":true},"type":"Float"},"pName":{"define":"pName","label":"名称","name":"pName","relation":"pName","type":"String"},"pPrice":{"define":"pPrice","label":"单价","name":"pPrice","relation":"pPrice","rules":{"number":true},"type":"Float"}},"directDelete":false,"events":{},"idColumn":"pID","limit":20,"xid":"cartData"});
 new __Data__(this,{"autoLoad":false,"autoNew":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"pSumMoney":{"define":"pSumMoney","label":"合计金额","name":"pSumMoney","relation":"pSumMoney","rules":{"calculate":"$model.cartData.sum(\"pMoney\")","number":true},"type":"Float"}},"directDelete":false,"events":{},"idColumn":"pSumMoney","limit":20,"xid":"calcData"});
}}); 
return __result;});