define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	
	var Model = function(){
		this.callParent();
	};

	Model.prototype.modelLoad = function(event){
		
	};
	
	//得到图片路径，将相对路径转换为绝对路径
	Model.prototype.getImgUrl = function(imgUrl){
		return require.toUrl("./img/"+imgUrl);
	};
	
	//主页的"来一份"按钮的点击事件
	Model.prototype.addCartBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		var rows = this.comp("cartData").find(["pID"], [row.getID()]);
		if(rows.length == 0){
			this.comp("cartData").newData({
				defaultValues:[{
					//为其购物车中的变量赋值，产品名，产品数量，产品单价
					"pID": row.getID(),
					"pName": row.val("pName"),
					"pPrice": row.val("pPrice"),
					"pCount": 1
				}]
			});
		}else{
			rows[0].val("pCount",rows[0].val("pCount")+1); 
		}
	};

	//购物车页的“+”按钮的点击操作时间
	Model.prototype.addBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		row.val("pCount",row.val("pCount")+1);  //val();此方法是给一个参数是取值，给两个参数是赋值
	};

	Model.prototype.subBtnClick = function(event){
		var row = event.bindingContext.$object;  //   获取当前行
		if(row.val("pCount") > 0){
			row.val("pCount",row.val("pCount") - 1);  //val();此方法是给一个参数是取值，给两个参数是赋值
		}

	};

	return Model;
});